
library(shiny)
library(scales)

# Define UI for app that draws a histogram ----
ui <- fluidPage(
  
  # App title ----
  # titlePanel("Illustration of Hypothesis Tests"),
  
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    
    # Sidebar panel for inputs ----
    sidebarPanel(
      
      # Input 1: Null hypothesis ----
      sliderInput(inputId = "t.act",
                  label = withMathJax(
                    'Actual test value \\(t^{act}\\)'
                  ),
                  min = as.numeric(-6),
                  max =  as.numeric(6),
                  value = as.numeric(0),
                  # round = FALSE,
                  step = 0.20),
      
      # Input 2: Select type of the test ----
      selectInput("test",
                  label = "Test form:",
                  choices = list("Two sided" = "two_sid", "One sided, less or equal" = "one_sid_leq", "One sided, greater or equal" = "one_sid_geq"),
                  selected = "two_sid"),
      
    ),
    
    # Main panel for displaying outputs ----
    mainPanel(
      
      fluidRow(
        
        column(12,
               HTML("<hr>"),
               h3("Probability Density Function (PDF)"),
               plotOutput("Plot01")),
        # column(12,
        #        h3("Notes"),
        #        htmlOutput("Text01")),
        column(12,
               HTML("<hr>"),
               h3("Cumulative Distribution Function (CDF)"),
               plotOutput("Plot02")),
        

        column(12,
               # h3("Result"),
               HTML("<hr>"),
               HTML("<span style='font-size: 16pt'>\\(p\\)-value</span><script>if (window.MathJax) MathJax.Hub.Queue(['Typeset', MathJax.Hub]);</script>"),
               htmlOutput("Text02"))
        
      )
    )
  )
)

server <- function(input, output) {

  #..................................................
  # Illustration 1: Test ----
  output$Plot01 <- renderPlot({
    
    # test statistic
    t.act <- as.numeric(input$t.act)
    # test    
    test <- input$test
    
    # plot parameters
    par(mfrow=c(1,1),
        mar=c(4,2,5,10))
    #bottom, left, top, and right
    
    # One-sided less or equal ----
    if (test==c("one_sid_leq")){
      # plot the standard normal density on the interval [-6,6]
      curve(dnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,0.45),
            cex.lab = 1.5,
            col = alpha("black", 0.25))
      lines(seq(0,6,0.01),dnorm(seq(0,6,0.01)),
            lwd = 2,
            col = alpha("black", 1))
      # add x-axis
      axis(3,at = c(-6, 0, 1.64, 2.33, 6), las=2,
           labels = c("", "0", "1.64", "2.33", ""),
           cex.axis = 1.5)
      axis(1,at = c(-6, round(t.act,3), 6),
           cex.axis = 1.5)
      # shade p-value region in right tail
      if (t.act <= 6) {
        polygon(x = c(t.act, seq(t.act, 6, 0.01), 6),
                y = c(0, dnorm(seq(t.act, 6, 0.01)), 0), 
                col = "steelblue")
      }
      # add critical value lines
      abline(v=1.64, lty=2, lwd=2)
      abline(v=2.33, lty=2, lwd=2)
      # add actual test value lines
      abline(v=t.act, col="red", lty=2, lwd=2)
      
    # One-sided greater or equal ----
    } else if (test==c("one_sid_geq")){
      # plot the standard normal density on the interval [-6,6]
      curve(dnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,0.45),
            cex.lab = 1.5,
            col = alpha("black", 0.25))
      lines(seq(-6,0,0.01),dnorm(seq(-6,0,0.01)),
            lwd = 2,
            col = alpha("black", 1))
      # add x-axis
      axis(3,at = c(-6, -2.33, -1.64, 0, 6), las=2,
           labels = c("", "-2.33", "-1.64", "0", ""),
           cex.axis = 1.5)
      axis(1,at = c(-6, round(t.act,3), 6),
           cex.axis = 1.5)
      # shade p-value region in left tail
      if (t.act > -6) {
        polygon(x = c(-6, seq(-6, t.act, 0.01), t.act),
                y = c(0, dnorm(seq(-6, t.act, 0.01)), 0), 
                col = "steelblue")
      }
      # add critical value lines
      abline(v=-1.64, lty=2, lwd=2)
      abline(v=-2.33, lty=2, lwd=2)
      # add actual test value lines
      abline(v=t.act, col="red", lty=2, lwd=2)
      
    # Two-sided less or equal ----
    } else if (test==c("two_sid") && t.act <=0) { 
      # plot the standard normal density on the interval [-6,6]
      curve(dnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,0.45),
            cex.lab = 1.5,
            col = alpha("black", 0.25))
      lines(seq(-6,0,0.01),dnorm(seq(-6,0,0.01)),
            lwd = 2,
            col = alpha("black", 1))
      # add x-axis top
      axis(3,at = c(-6, -2.58, -1.96, 0), las=2, # left tail axis crit. values (here relevant!)
           labels = c("","-2.58", "-1.96", "0"),
           cex.axis = 1.5)
      axis(3,at = c(0, 1.96, 2.58, 6), las=2, # right tail axis crit. values (here not relevant!)
           labels = c("0", "1.96", "2.58", ""),
           cex.axis = 1.5,
           col.axis = alpha("black",0.25))
      
      # # add x-axis bottom
      # axis(1,at = c(-6, 0), # left tail (here relevant!)
      #      labels = c("", ""),
      #      cex.axis = 1.5)
      # axis(1,at = c(round(t.act,3), 0), # left tail actual test statistic (here relevant!)
      #      labels = c(round(t.act,3), "0"),
      #      cex.axis = 1.5)
      # axis(1,at = c(0, 6), # right tail (here not relevant!) 
      #      labels = c("", ""),
      #      cex.axis = 1.5,
      #      col.axis = alpha("black",0.25))
      # axis(1,at = c(0, round(-t.act,3)), # right tail actual test statistic (here not relevant!)
      #      labels = c("0",round(-t.act,3)),
      #      cex.axis = 1.5,
      #      col.axis = alpha("black", 0.25))
      
      # add x-axis bottom
      axis(1,at = c(-6, 0), # left tail (here relevant!)
           labels = c("", ""),
           cex.axis = 1.5)
      axis(1,at = t.act, # left tail actual test statistic (here relevant!)
           labels = format(t.act, nsmall = 2),
           cex.axis = 1.5)
      axis(1,at = c(0, 6), # right tail (here not relevant!) 
           labels = c("", ""),
           cex.axis = 1.5,
           col.axis = alpha("black",0.25))
      axis(1,at = -t.act, # right tail actual test statistic (here not relevant!)
           labels = format(-t.act, nsmall = 2),
           cex.axis = 1.5,
           col.axis = alpha("black", 0.25))
      
      # shade p-value/2 region in left tail
      if (t.act > -6) {
        polygon(x = c(-6, seq(-6, t.act, 0.01), t.act),
                y = c(0, dnorm(seq(-6, t.act, 0.01)),0), 
                col = "steelblue",
                border =  NA)
      }
      # shade p-value/2 region in right tail
      if (-t.act < 6) {
        polygon(x = c(-t.act, seq(-t.act, 6, 0.01), 6),
                y = c(0, dnorm(seq(-t.act, 6, 0.01)), 0), 
                col = alpha("steelblue",0.5),
                border = NA)
      }
      # add critical value lines
      abline(v=-1.96, lty=2, lwd=2)
      abline(v= 1.96, lty=2, lwd=2, col=alpha("black",0.5))
      abline(v=-2.58, lty=2, lwd=2)
      abline(v= 2.58, lty=2, lwd=2, col=alpha("black",0.5))
      # add actual test value lines
      abline(v=-t.act, lty=2, lwd=2, col=alpha("red",0.5))
      abline(v=t.act, col="red", lty=2, lwd=2)
    } else if (test==c("two_sid") && t.act > 0) { # right tail
      # plot the standard normal density on the interval [-6,6]
      curve(dnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,0.45),
            cex.lab = 1.5,
            col = alpha("black", 0.25))
      lines(seq(0,6,0.01),dnorm(seq(0,6,0.01)),
            lwd = 2,
            col = alpha("black", 1))
      # add x-axis top
      axis(3,at = c(-6, -2.58, -1.96, 0), las=2, # left tail axis crit. values (here not relevant!)
           labels = c("","-2.58", "-1.96", "0"),
           cex.axis = 1.5,
           col.axis = alpha("black",0.25))
      axis(3,at = c(0, 1.96, 2.58, 6), las=2, # right tail axis crit. values (here relevant!)
           labels = c("0", "1.96", "2.58", ""),
           cex.axis = 1.5)
      
      # # add x-axis bottom
      # axis(1,at = c(0, 6), # right tail (here relevant!)
      #      labels = c("", ""),
      #      cex.axis = 1.5)
      # axis(1,at = c(0, round(t.act,3)), # right tail actual test statistic (here relevant!)
      #      labels = c("0", round(t.act,3)),
      #      cex.axis = 1.5)
      # axis(1,at = c(-6, 0), # left tail (here not relevant!)
      #      labels = c("", ""),
      #      cex.axis = 1.5,
      #      col.axis = alpha("black",0.25))
      # axis(1,at = c(round(-t.act,2), 0), # left tail actual test statistic (here not relevant!)
      #      labels = c(round(-t.act,2), "0"),
      #      cex.axis = 1.5,
      #      col.axis = alpha("black", 0.25))
      
      # add x-axis bottom
      axis(1,at = c(0, 6), # right tail (here relevant!)
           labels = c("", ""),
           cex.axis = 1.5)
      axis(1,at = t.act, # right tail actual test statistic (here relevant!)
           labels = format(t.act, nsmall = 2),
           cex.axis = 1.5)
      axis(1,at = c(-6, 0), # left tail (here not relevant!)
           labels = c("", ""),
           cex.axis = 1.5,
           col.axis = alpha("black",0.25))
      axis(1,at = -t.act, # left tail actual test statistic (here not relevant!)
           labels = format(-t.act, nsmall = 2),
           cex.axis = 1.5,
           col.axis = alpha("black", 0.25))
      
      # shade p-value/2 region in left tail
      if (-t.act > -6) {
        polygon(x = c(-6, seq(-6, -t.act, 0.01), -t.act),
                y = c(0, dnorm(seq(-6, -t.act, 0.01)),0), 
                col = alpha("steelblue",0.5),
                border =  NA)
      }
      # shade p-value/2 region in right tail
      if (t.act < 6) {
        polygon(x = c(t.act, seq(t.act, 6, 0.01), 6),
                y = c(0, dnorm(seq(t.act, 6, 0.01)), 0), 
                col = "steelblue",
                border = NA)
      }
      # add critical value lines
      abline(v=-1.96, lty=2, lwd=2, col=alpha("black",0.5))
      abline(v= 1.96, lty=2, lwd=2)
      abline(v=-2.58, lty=2, lwd=2, col=alpha("black",0.5))
      abline(v= 2.58, lty=2, lwd=2)
      # add actual test value lines
      abline(v=-t.act, lty=2, lwd=2, col=alpha("red",0.5))
      abline(v=t.act, col="red", lty=2, lwd=2)
    }
    
  })
  
  # output$Text01 <- renderText({ 
  #   
  #   if (input$test == c("two_sid")) {
  #     paste0("<span style='text-decoration: underline'> Note, using a two-sided test... this is $$t^{act}=", as.numeric(input$t.act), "$$<span> <script>if (window.MathJax) MathJax.Hub.Queue(['Typeset', MathJax.Hub]);</script>")
  #   } else if (input$test == c("one_sid_geq")) {
  #     paste0("<span style='text-decoration: underline'> Note, using a one-sided test greater or equal...<span>")
  #   } else if (input$test == c("one_sid_leq")) {
  #     paste0("<span style='text-decoration: underline'> Note, using a one-sided test greater or equal...<span>")
  #   }
  #   
  # })
  
  
  
  #..................................................
  # Illustration 2: CDF of test statistic ----
  output$Plot02 <- renderPlot({
    
    # test statistic
    t.act <- input$t.act
    z <- t.act
    phi.z <- pnorm(t.act)
    # test
    test <- input$test
    
    # plot parameters
    par(mfrow=c(1,1),
        mar=c(2,3,4,10))
    #bottom, left, top, and right
    
    # Two-sided ----
    if (test==c("two_sid")) {
    
      # use always the negative absolute value
      z <- -abs(z)
      phi.z <- pnorm(-abs(z))
      
      # plot standard normal cumulative density on the interval [-6,6]
      curve(pnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,1),
            cex.lab = 1.5,
            col = alpha("black", 0.25))
      lines( seq(-6, 0, 0.01),pnorm( seq(-6, 0, 0.01)))
      axis(1,at = c(-6, 0, 6), las=2,
           labels = c("", "0", ""),
           cex.axis = 1.5)
      axis(2,at = seq(0,1,0.1), las=2,
           labels = as.character(seq(0,1,0.1)),
           cex.axis = 1.5)
      abline(h=phi.z, col="steelblue", lty=2, lwd=2)
      abline(v=z, col="red", lty=2, lwd=2)
      axis(3,at = c(-6, round(z,3), 6), las=1,
           labels = c("", as.character(round(z,3)), ""),
           cex.axis = 1.5, col.axis = "red")
      axis(4,at = c(round(phi.z,3)), las=1,
           labels = bquote(phi(.(round(z,3)))== .(round(phi.z,3))),
           cex.axis = 1.5, col.axis = "steelblue")
      
      # # rect(xleft=-2, ybottom=0.7, xright=6, ytop=0.95, col="white", border = NA)
      # rect(xleft=-0.55, ybottom=0.81, xright=6.45, ytop=0.925, col="white", border=NA)
      # add.text.01 <- expression(paste("For a two-sided test we only check negative values,", " -|", t^{act}, "|"))
      # add.text.02 <- expression("Thus, only the lower tail is relevant here!")
      # text(x = 3, y = 0.90, add.text.01, cex = 1)
      # text(x = 3, y = 0.85, add.text.02, cex = 1)
    
    # One-sided ----
    } else {
      
      # plot standard normal density on the interval [-6,6]
      curve(pnorm(x),
            xlim = c(-6, 6),
            yaxs = "i",
            xlab = "z",
            ylab = "",
            lwd = 2,
            axes = "F",
            ylim = c(0,1),
            cex.lab = 1.5,
            col = "black")
      axis(1,at = c(-6, 0, 6), las=2,
           labels = c("", "0", ""),
           cex.axis = 1.5)
      axis(2,at = seq(0,1,0.1), las=2,
           labels = as.character(seq(0,1,0.1)),
           cex.axis = 1.5)
      abline(h=phi.z, col="steelblue", lty=2, lwd=2)
      abline(v=z, col="red", lty=2, lwd=2)
      axis(3,at = c(-6, round(z,3), 6), las=1,
           labels = c("", as.character(round(z,3)), ""),
           cex.axis = 1.5, col.axis = "red")
      axis(4,at = c(round(phi.z,3)), las=1,
           labels = c(as.character(round(phi.z,3))),
           cex.axis = 1.5, col.axis = "steelblue")
      legend("topleft",inset=.05,legend="CDF",bg="white",
             xjust=0.5,yjust=0.5,x.intersp=-0.5,y.intersp=1,cex=1)
      
    }
    
  })
  
  output$Text02 <- renderText({ 
    
    if (input$test==c("two_sid")) {
      paste0("<span style='text-decoration: none; font-size: 14pt'> Remember, in the case of a two-sided test we compute: $$p\\text{-value}=\\Phi\\left(-\\left|t^{act}\\right|\\right)=", format(pnorm(-abs(as.numeric(input$t.act))), digits=2, nsmall=2), "$$<span> <script>if (window.MathJax) MathJax.Hub.Queue(['Typeset', MathJax.Hub]);</script>")
    } else if (input$test==c("one_sid_geq")) {
      paste0("<span style='text-decoration: none; font-size: 14pt'> Remember, in the case of a one-sided greater or equal test we compute: $$p\\text{-value}=\\Phi\\left(t^{act}\\right)=", format(pnorm(as.numeric(input$t.act)), digits=2, nsmall=2), "$$<span> <script>if (window.MathJax) MathJax.Hub.Queue(['Typeset', MathJax.Hub]);</script>")
    } else if (input$test==c("one_sid_leq")) {
      paste0("<span style='text-decoration: none; font-size: 14pt'> Remember, in the case of a one-sided less or equal test we compute: $$p\\text{-value}=1-\\Phi\\left(t^{act}\\right)=", format(1-pnorm(as.numeric(input$t.act)), digits=2, nsmall=2), "$$<span> <script>if (window.MathJax) MathJax.Hub.Queue(['Typeset', MathJax.Hub]);</script>")
    }
    
    # txt

  })
  
  #
  
  
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)
